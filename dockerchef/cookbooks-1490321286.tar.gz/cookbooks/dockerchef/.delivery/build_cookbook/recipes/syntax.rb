#
# Cookbook:: build_cookbook
# Recipe:: syntax
#
# Copyright:: 2017, The Authors, All Rights Reserved.
include_recipe 'delivery-truck::syntax'
